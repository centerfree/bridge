import cv2
import numpy
import dlib
from utils import *
from face_utils import *
from tensorflow.keras import backend
from tensorflow.keras.models import load_model
import timeseries
from time import process_time as time

colors = [(numpy.random.randint(0, 255, dtype=numpy.uint8),
           numpy.random.randint(0, 255, dtype=numpy.uint8),
           numpy.random.randint(0, 255, dtype=numpy.uint8)) for i in range(1000)]
colors = tuple(colors)

stabilization_wait_msg = 'Waiting for video to stabilize...'
detected_parts_msg = ' !!! Press any key to continue !!! These parts were detected for tracking...'
color_volume_msg = 'Observing color changes in face. Press Esc to terminate at current frame...'
perfusion_map_msg = ' !!! Press any key to continue !!! Estimated blood perfusion...'
decoder_path = 'hrvnet-25hz-5sec.bin'
decoder = load_model(decoder_path, custom_objects={'backend': backend})

parts_str = ['left cheek',
             'right cheek',
             'left chin',
             'right chin',
             'left forehead',
             'right forehead',
             'central forehead']
font = {'size': '48',
        'color': 'red'}


def moving_average(a, n=25):
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n


def find_peaks_1d(x, min_dist=1, axis=-1):
    from scipy.ndimage import maximum_filter1d
    x_ = maximum_filter1d(x, size=min_dist, axis=axis)
    return x == x_


def decode_ppg(noisy_ppg: numpy.ndarray):
    assert noisy_ppg.ndim == 1
    decoder_len = 125
    pad_len = decoder_len - (noisy_ppg.size % decoder_len)
    noisy_ppg_padded = numpy.pad(noisy_ppg, ((0, pad_len),), mode='edge').reshape((-1, decoder_len, 1))
    noisy_ppg_padded[:, :, 0] = timeseries.norm1(noisy_ppg_padded[:, :, 0], axis=1)
    decoded_ppg, noise_levels = decoder.predict(noisy_ppg_padded)
    for i in range(1, decoded_ppg.shape[0]):
        decoded_ppg[i, :, 0] = decoded_ppg[i, :, 0]  # + decoded_ppg[i - 1, -1, 0] - decoded_ppg[i, 0, 0]
    decoded_ppg = decoded_ppg.reshape(-1)
    if pad_len > 0:
        return decoded_ppg[:noisy_ppg.size], noise_levels[:-1]
    else:
        return decoded_ppg[:noisy_ppg.size], noise_levels


def process_color_volume(color_volume, fs):
    noise_levels = []
    clean_ppg = []

    for part in color_volume:
        grid_noise = []
        grid_ppg = []
        for grid in part:
            green = numpy.array([triplet[1] for triplet in grid])
            if green.size > 0:
                bl = baseline(green, fs)
                y, s = decode_ppg(timeseries.norm1(green - bl))
                y = y - baseline(y, fs)  # experimental, to remove boundary effect
            else:
                y, s = green, 1.0
            grid_noise.append(s)
            grid_ppg.append(y)
        noise_levels.append(grid_noise)
        clean_ppg.append(grid_ppg)
    return clean_ppg, noise_levels


def baseline(signal: numpy.ndarray, fs: float = 25):
    bl = None
    if signal.size > 0:
        bl = numpy.convolve(signal, numpy.ones([int(fs), ]) / fs, 'valid')
        pl = signal.size - bl.size
        bl = numpy.pad(bl, ((int(pl / 2), pl - int(pl / 2)),), 'edge')
    return bl


def skip_frames_till_stable_face_detected(video: cv2.VideoCapture,
                                          stability_threshold: float = 0.1,
                                          min_face_size: float = 0.1,
                                          max_face_size: float = 0.8,
                                          face_detector=None,
                                          timeout=30,
                                          preprocess=None):
    """
    Reads a video object and skips frames till the video is stabilized and a unique and valid face is detected
    :param video:
    :param stability_threshold:
    :param min_face_size:
    :param max_face_size:
    :param face_detector:
    :param timeout:
    :param preprocess:
    :return:
    """
    default_face_detector_path = './haarcascade_frontalface_default.xml'
    while True:
        if video.isOpened():
            break
        if timeout == 0:
            break
        timeout -= 1
    if not video.isOpened():
        print('could not open video')
        return None
    else:
        if face_detector is None:
            face_detector = cv2.CascadeClassifier(default_face_detector_path)

        _, frame2 = video.read()
        if preprocess is not None:
            frame2 = preprocess(frame2)

        delta = 1.0
        while True:
            frame1 = numpy.copy(frame2)
            status, frame2 = video.read()
            if not status:
                break

            if preprocess is not None:
                frame2 = preprocess(frame2)

            delta = 0.9 * delta + 0.1 * numpy.square(frame2 - frame1).mean() / numpy.square(frame1).mean()
            cv2.imshow(stabilization_wait_msg, frame2)
            cv2.waitKey(1)

            if delta < stability_threshold:
                face = face_detector.detectMultiScale(frame2, 1.1)
                if len(face) != 1:
                    continue
                if float(face[0][2] * face[0][3]) < (min_face_size ** 2) * float(frame2.shape[0] * frame2.shape[1]):
                    continue
                if float(face[0][2] * face[0][3]) > (max_face_size ** 2) * float(frame2.shape[0] * frame2.shape[1]):
                    continue
                cv2.destroyWindow(stabilization_wait_msg)
                return face[0], frame2
        cv2.destroyWindow(stabilization_wait_msg)
        return None


def face_parts(face, frame):
    face_d = dlib.rectangle(int(face[0]), int(face[1]), int(face[0]) + int(face[2]), int(face[1]) + int(face[3]))
    landmarks = get_facial_landmarks(frame, face_d)
    parts_to_track = facial_planar_parts_mask(frame, face_d, landmarks)
    return parts_to_track


def draw_parts(parts, frame):
    # overlay of parts mask
    canvas_parts = [numpy.zeros(frame.shape[0:2]) for i in range(3)]
    for j, part in enumerate(parts):
        for i in range(3):
            canvas_parts[i][part > 0] = colors[j][i]
    canvas_parts = numpy.dstack(canvas_parts)
    return canvas_parts


def draw_grids(grids, frame):
    canvas_rect_fill = numpy.zeros_like(frame)
    canvas_rect_boundary = numpy.zeros_like(frame)
    for j, part_grids in enumerate(grids):
        for grid in part_grids:
            cv2.rectangle(canvas_rect_boundary,
                          (grid[0], grid[1]),
                          (grid[2], grid[3]),
                          cv_color(colors[j]),
                          thickness=1,
                          lineType=cv2.LINE_8
                          )
            for i in range(3):
                canvas_rect_fill[grid[1]:grid[3], grid[0]:grid[2], i] = colors[j][i]
    return overlay(canvas_rect_fill, canvas_rect_boundary, 0.5)


def track_color_volume(video, parts_to_track, initial_grids, initial_frame, num_frames=1000, preprocess=None):
    reference_kp_to_track = []
    n_parts = len(parts_to_track)

    for i in range(n_parts):
        reference_kp_to_track.append(
            numpy.squeeze(cv2.goodFeaturesToTrack(cv2.cvtColor(initial_frame, cv2.COLOR_BGR2GRAY),
                                                  50, 0.01, 2, None, parts_to_track[i])))
    lk_params = dict(winSize=(10, 10),
                     maxLevel=2,
                     criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))

    tracker = [[part.tolist() for part in reference_kp_to_track], ]
    tracker_validity = [[[True for _ in range(part.shape[0])] for part in reference_kp_to_track], ]
    last_frame = initial_frame.copy()
    last_frame_gray = cv2.cvtColor(last_frame, cv2.COLOR_BGR2GRAY)
    color_volume = [[[] for __ in _] for _ in initial_grids]

    counter = -1
    while video.isOpened() & (counter < num_frames):
        counter += 1

        status, new_frame = video.read()
        if not status:
            break
        if preprocess is not None:
            new_frame = preprocess(new_frame)

        new_frame_gray = cv2.cvtColor(new_frame, cv2.COLOR_BGR2GRAY)
        new_kp_to_track = []
        new_validity = []

        for i in range(len(parts_to_track)):
            p0 = numpy.array(tracker[-1][i], dtype=numpy.float32).reshape(-1, 1, 2)
            p1, _, _ = cv2.calcOpticalFlowPyrLK(last_frame_gray, new_frame_gray, p0, None, **lk_params)
            p0r, _, _ = cv2.calcOpticalFlowPyrLK(new_frame_gray, last_frame_gray, p1, None, **lk_params)
            d = abs(p0 - p0r).reshape(-1, 2).max(-1)
            good = (d < 1).tolist()

            new_validity.append([(good[j] and tracker_validity[-1][i][j]) for j in range(len(good))])
            new_kp_to_track.append(numpy.squeeze(p1).tolist())

        tracker_validity.append(new_validity)
        tracker.append(new_kp_to_track)
        last_frame_gray = new_frame_gray.copy()

        canvas_parts = [numpy.zeros(initial_frame.shape[0:2]) for i in range(3)]

        for part_i in range(len(tracker[0])):
            ref_part = numpy.array(tracker[0][part_i])
            new_part = numpy.array(tracker[-1][part_i])
            homography, status = cv2.findHomography(ref_part, new_part)

            new_frame_registered = cv2.warpPerspective(new_frame, homography, new_frame.shape[::-1][1:])

            part_mask_tracked = cv2.warpPerspective(parts_to_track[part_i], homography,
                                                    parts_to_track[part_i].shape[::-1])  # (width, height) > ::-1
            for channel in range(3):
                canvas_parts[channel][part_mask_tracked > 0] = colors[part_i][channel]

            for grid_i in range(len(initial_grids[part_i])):
                init_rect = initial_grids[part_i][grid_i]
                temp = new_frame_registered[int(init_rect[1]): int(init_rect[3]),
                       int(init_rect[0]): int(init_rect[2]), :]

                color_volume[part_i][grid_i].append(
                    [temp[:, :, channel].mean() for channel in range(3)])

        canvas_parts = numpy.dstack(canvas_parts).astype(numpy.uint8)

        cv2.imshow(color_volume_msg, canvas_parts)
        key = cv2.waitKey(1)
        if key == 27:
            break
        if counter % 25 == 0:
            print("%d frames processed..." % counter)

    cv2.destroyWindow(color_volume_msg)
    return color_volume


def test_skip_frames_till_stable_face_detected():
    detector_path = './haarcascade_frontalface_default.xml'
    video_path = "ashish_apnea.mp4"
    face_cascade = cv2.CascadeClassifier(detector_path)
    video = cv2.VideoCapture(video_path)
    face, frame = skip_frames_till_stable_face_detected(video, 0.05, face_detector=face_cascade)
    print(face)
    frame = cv2.rectangle(frame, (face[0], face[1]), (face[0] + face[2], face[1] + face[3]),
                          color=cv_color([0, 200, 200]), thickness=2)
    cv2.imshow(detected_parts_msg, frame)
    cv2.waitKey()
    cv2.destroyWindow(detected_parts_msg)
    exit(0)


def test_parts_utils():
    video_path = "ashish_apnea.mp4"
    video = cv2.VideoCapture(video_path)
    face, frame = skip_frames_till_stable_face_detected(video, 0.05)
    face_pt = (face[0], face[1], face[0] + face[2], face[1] + face[3])
    parts = face_parts(face, frame)
    initial_grids = [divide_part_to_grid(part, 20, 20, face_pt) for part in parts]

    parts_canvas = draw_parts(parts, frame).astype(numpy.uint8)
    grids_canvas = draw_grids(initial_grids, frame)
    init_visualization = overlay(frame, overlay(parts_canvas, grids_canvas, 0.5))
    cv2.imshow(detected_parts_msg, init_visualization)
    cv2.waitKey()
    cv2.destroyWindow(detected_parts_msg)

    color_volume = track_color_volume(video, parts, initial_grids, frame)

    exit(0)


def perfusion_map(grids, perfusion_values, frame, color=(0, 0, 255)):
    canvas = numpy.zeros_like(frame)
    for j, part_grids in enumerate(grids):
        for k, grid in enumerate(part_grids):
            for i in range(3):
                canvas[grid[1]:grid[3], grid[0]:grid[2], i] = int((perfusion_values[j][k] ** 5) * color[i])
    return canvas


def nested_list_to_flat_list(nested_list):
    temp_list = []

    def ravel(inner_list, flat_list: list):
        if isinstance(inner_list, list):
            for item in inner_list:
                flat_list = ravel(item, flat_list)
        else:
            flat_list.append(inner_list)
        return flat_list

    temp_list = ravel(nested_list, temp_list)
    return temp_list


def test_decoder():
    import pickle
    import matplotlib.pyplot as plotter
    f = open('debug_vars_long.bin', 'rb')
    color_volume = pickle.load(f)
    f.close()
    sigs, noises = process_color_volume(color_volume)
    med_noises = [[1 - numpy.median(grid_noises) for grid_noises in part_noises] for part_noises in noises]
    for i in range(len(parts_str)):
        print(parts_str[i], med_noises[i])
    sigs_ = []
    for part in sigs:
        for grid in part:
            if len(grid) > 0:
                sigs_.append(grid.tolist())
    sigs_ = numpy.array(sigs_)
    from sklearn.decomposition import PCA
    pca = PCA(n_components=3)
    sigs_common = pca.fit_transform(sigs_.T).T
    plotter.plot(sigs_common[0, :])

    for i in sigs:
        for j in i:
            plotter.clf()
            plotter.plot(j)
            plotter.pause(3)

    video_path = "ashish_apnea.mp4"
    video = cv2.VideoCapture(video_path)
    face, frame = skip_frames_till_stable_face_detected(video, 0.05)
    face_pt = (face[0], face[1], face[0] + face[2], face[1] + face[3])
    parts = face_parts(face, frame)
    initial_grids = [divide_part_to_grid(part, 20, 20, face_pt) for part in parts]

    map_colorized = perfusion_map(initial_grids, med_noises, frame)
    cv2.imshow('', map_colorized)
    cv2.waitKey()
    cv2.destroyAllWindows()


def plot_noisy_and_clean_signals(noisy, clean, fs):
    from matplotlib import pyplot as plotter
    from scipy.signal import welch
    for i in range(len(noisy)):
        figure, axes = plotter.subplots(len(noisy[i]), 4)
        figure.suptitle(parts_str[i])
        for j in range(len(noisy[i])):
            green = numpy.array([triplet[1] for triplet in noisy[i][j]])
            green = green - baseline(green)
            axes[j, 0].plot(green)
            axes[j, 1].plot(clean[i][j])
            f, fg = welch(green, fs=fs)
            f, fc = welch(clean[i][j], fs=fs)
            axes[j, 2].plot(f, fg)
            axes[j, 3].plot(f, fc)
    plotter.draw()


def green_from_color_volume(volume):
    green = []
    for part in volume:
        part_green = []
        for grid in part:
            grid_green = [triplet[1] for triplet in grid]
            part_green.append(numpy.array(grid_green))
        green.append(part_green)
    return green


def central_frequency(signals, fs):
    from scipy.signal import welch
    signals_ = numpy.array(nested_list_to_flat_list(signals))
    for i in range(signals_.shape[0]):
        signals_[i, :] = signals_[i, :] - baseline(signals_[i, :])
    f, p = welch(signals_, fs=fs, axis=1)
    p = numpy.mean(p, axis=0)
    return f[numpy.argmax(p)]


def spectrum_quality(sample_frequencies, spectrum, cf, delta_f=0.2, lo=0.5, hi=4.0):
    return numpy.sum((sample_frequencies < cf + delta_f).astype(numpy.float) *
                     (sample_frequencies > cf - delta_f).astype(numpy.float) * spectrum) / \
           numpy.sum((sample_frequencies < hi).astype(numpy.float) *
                     (sample_frequencies > lo).astype(numpy.float) * spectrum)


def weighted_mean(signals, weights):
    signals_ = nested_list_to_flat_list(signals)
    weights_ = nested_list_to_flat_list(weights)
    temp = numpy.zeros_like(signals_[0])
    for i in range(len(signals_)):
        temp += signals_[i] * weights_[i]
    return temp / len(signals_)


def example_script(video_path: str = 0, summary_path=None):
    def preprocess(numpy_image3):
        numpy_image3 = cv2.rotate(numpy_image3, cv2.ROTATE_90_CLOCKWISE)
        return numpy_image3

    import pickle
    if summary_path is None:
        summary_path = video_path[:-4] + '_summary.bin' if isinstance(video_path, str) else '_summary.bin'
    summary = dict()
    summary_writer = open(summary_path, 'wb')
    try:
        video = cv2.VideoCapture(video_path)
        fps = int(video.get(cv2.CAP_PROP_FPS))
        print("Video FPS is %d", int(fps))

        face, frame = skip_frames_till_stable_face_detected(video, 0.05, preprocess=preprocess)
        face_pt = (face[0], face[1], face[0] + face[2], face[1] + face[3])
        parts = face_parts(face, frame)
        initial_grids = [divide_part_to_grid(part, 20, 20, face_pt) for part in parts]
        for item in initial_grids:
            print(len(item))

        parts_canvas = draw_parts(parts, frame).astype(numpy.uint8)
        grids_canvas = draw_grids(initial_grids, frame)
        init_visualization = overlay(frame, overlay(parts_canvas, grids_canvas, 0.5))
        summary['init_visualization'] = init_visualization
        cv2.imshow(detected_parts_msg, init_visualization)
        cv2.waitKey()
        cv2.destroyWindow(detected_parts_msg)

        color_volume = track_color_volume(video, parts, initial_grids, frame, num_frames=300, preprocess=preprocess)
        summary['color_volume'] = color_volume

        signals, noises = process_color_volume(color_volume, fs=fps)
        summary['signals'] = signals
        summary['noises'] = noises
        median_noises = [[1 - numpy.median(grid_noises) for grid_noises in part_noises] for part_noises in noises]
        for i in range(len(parts_str)):
            print(parts_str[i], median_noises[i])

        map_colorized = perfusion_map(initial_grids, median_noises, frame)
        summary['map_colorized'] = map_colorized
        cv2.imshow(perfusion_map_msg, map_colorized)
        cv2.waitKey()
        cv2.destroyWindow(perfusion_map_msg)

        signals_array = nested_list_to_flat_list(signals)
        signals_array_ = []
        for signal in signals_array:
            if isinstance(signal, numpy.ndarray):
                if signal.size > 0:
                    signals_array_.append(signal)
        signals_array = numpy.array(signals_array_)
        from sklearn.decomposition import PCA, FastICA
        # pca = PCA(n_components=1)
        pca = FastICA(n_components=1)
        ppg_clean = pca.fit_transform(signals_array.T).T[0, :]
        summary['ppg_clean'] = ppg_clean

        import matplotlib.pyplot as plotter
        plotter.plot(ppg_clean)
        plotter.title('clean_ppg')
        plotter.draw()
        plotter.pause(0.01)

        plot_noisy_and_clean_signals(color_volume, signals)

        green = green_from_color_volume(color_volume)
        from scipy.signal import welch
        from scipy.signal import find_peaks_cwt
        for i in range(len(green)):
            for j in range(len(green[i])):
                green[i][j] -= baseline(green[i][j], fps)
        cf = central_frequency(green, fps)
        quality = [[spectrum_quality(*welch(grid, fps), cf=cf) for grid in part] for part in green]
        ppg_clean_1 = weighted_mean(green, quality)
        ppg_clean_2 = weighted_mean(green, median_noises)
        ppg_clean_1_filtered = decode_ppg(ppg_clean_1)[0] - baseline(decode_ppg(ppg_clean_1)[0], fps)
        ppg_clean_2_filtered = decode_ppg(ppg_clean_2)[0] - baseline(decode_ppg(ppg_clean_2)[0], fps)
        for i in range(len(parts_str)):
            print(parts_str[i], quality[i])
        plotter.plot(ppg_clean_1, 'c')
        plotter.plot(ppg_clean_2, 'm')
        plotter.plot(ppg_clean_1_filtered, 'g')
        plotter.plot(ppg_clean_2_filtered, 'r')
        peaks1 = find_peaks_1d(ppg_clean_1_filtered, int(fps / 2))
        peaks1_idx = numpy.arange(peaks1.size)[peaks1]
        beat_intervals1 = numpy.diff(peaks1_idx, 1)
        beat_intervals1 = beat_intervals1[1:-1]  # remove first and last peaks as they might be spurious
        print(numpy.mean(beat_intervals1), numpy.median(beat_intervals1),
              numpy.var(beat_intervals1), 60.0 * fps / numpy.median(beat_intervals1))
        plotter.scatter(numpy.arange(peaks1.size)[peaks1], ppg_clean_1_filtered[peaks1])

        plotter.draw()
    finally:
        try:
            pickle.dump(summary, summary_writer)
        finally:
            summary_writer.close()


def heart_rate(video_path: str, summary_path=None):
    from scipy.signal import welch
    import pickle
    from matplotlib import pyplot as plotter

    def preprocess(numpy_image3):
        # numpy_image3 = cv2.rotate(numpy_image3, cv2.ROTATE_90_CLOCKWISE)
        return numpy_image3

    if summary_path is None:
        summary_path = video_path[:-4] + '_summary_hr.bin' if isinstance(video_path, str) else '_summary_hr.bin'
    summary = dict()
    summary_writer = open(summary_path, 'wb')

    try:
        video = cv2.VideoCapture(video_path)
        fps = round(video.get(cv2.CAP_PROP_FPS))
        print("Video FPS is %d" % int(fps))
        summary['fps'] = fps

        face, frame = skip_frames_till_stable_face_detected(video, 0.05, preprocess=preprocess)
        face_pt = (face[0], face[1], face[0] + face[2], face[1] + face[3])
        parts = face_parts(face, frame)
        initial_grids = [divide_part_to_grid(part, 20, 20, face_pt) for part in parts]

        parts_canvas = draw_parts(parts, frame).astype(numpy.uint8)
        grids_canvas = draw_grids(initial_grids, frame)
        init_visualization = overlay(frame, overlay(parts_canvas, grids_canvas, 0.5))
        summary['init_visualization'] = init_visualization

        cv2.imshow(detected_parts_msg, init_visualization)
        cv2.waitKey()
        cv2.destroyWindow(detected_parts_msg)

        color_volume = track_color_volume(video, parts[0:2], initial_grids[0:2], frame, preprocess=preprocess)
        green = green_from_color_volume(color_volume)
        for i in range(len(green)):
            for j in range(len(green[i])):
                green[i][j] -= baseline(green[i][j], fps)

        summary['color_volume'] = color_volume
        summary['green'] = green

        signals, noises = process_color_volume(color_volume, fps)
        summary['signals'] = signals
        summary['noises'] = noises

        median_noises = [[1 - numpy.median(grid_noises) for grid_noises in part_noises] for part_noises in noises]
        cf = central_frequency(green, fps)
        quality = [[spectrum_quality(*welch(grid, fps), cf=cf) for grid in part] for part in green]

        ppg_clean_1 = weighted_mean(green, quality)
        ppg_clean_2 = weighted_mean(green, median_noises)
        ppg_clean_1_filtered = decode_ppg(ppg_clean_1)[0] - baseline(decode_ppg(ppg_clean_1)[0], fps)
        ppg_clean_2_filtered = decode_ppg(ppg_clean_2)[0] - baseline(decode_ppg(ppg_clean_2)[0], fps)
        summary['ppg_clean_1'] = ppg_clean_1
        summary['ppg_clean_2'] = ppg_clean_2
        summary['ppg_clean_1_filtered'] = ppg_clean_1_filtered
        summary['ppg_clean_2_filtered'] = ppg_clean_2_filtered

        peaks1 = find_peaks_1d(ppg_clean_1_filtered, int(2 * fps / 3))
        peaks1_idx = numpy.arange(peaks1.size)[peaks1]
        beat_intervals1 = numpy.diff(peaks1_idx, 1)[1:-1]  # remove first and last peaks as they might be spurious

        peaks2 = find_peaks_1d(ppg_clean_2_filtered, int(2 * fps / 3))
        peaks2_idx = numpy.arange(peaks2.size)[peaks2]
        beat_intervals2 = numpy.diff(peaks2_idx, 1)[1:-1]  # remove first and last peaks as they might be spurious

        rr_stats = [numpy.mean(beat_intervals1), numpy.mean(beat_intervals2),
                    numpy.median(beat_intervals1), numpy.median(beat_intervals2)]
        rr_min, rr_max = numpy.percentile(beat_intervals1, [10, 90])
        print(rr_stats, rr_min, rr_max)

        rr_mean = numpy.mean(beat_intervals1[numpy.logical_and(beat_intervals1 > rr_min,
                                                               beat_intervals1 < rr_max)])

        plotter.plot(numpy.arange(ppg_clean_1_filtered.size) / fps, ppg_clean_1_filtered, 'r')
        plotter.plot(numpy.arange(ppg_clean_1_filtered.size) / fps, 5 * ppg_clean_1, 'y')
        plotter.scatter(numpy.array(peaks1_idx) / fps, ppg_clean_1_filtered[peaks1_idx])
        plotter.xlabel('Time (seconds)')
        plotter.ylabel('Estimated PPG')
        plotter.title('Heart Rate: %d' % int(60 * fps / rr_mean), **font)
        plotter.pause(100)

    finally:
        try:
            pickle.dump(summary, summary_writer)
        finally:
            summary_writer.close()


if __name__ == '__main__':
    # test_skip_frames_till_stable_face_detected()
    # test_parts_utils()
    # test_decoder()
    import pickle
    from matplotlib import pyplot as plotter
    import  os
    import tkinter
    from tkinter import filedialog

    root = tkinter.Tk()
    root.withdraw()  # use to hide tkinter window
    vid_path = filedialog.askopenfilename(filetypes=(("All files", "*"),), initialdir='.')
    heart_rate(vid_path)
    exit(0)
