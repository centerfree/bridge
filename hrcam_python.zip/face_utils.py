import numpy as np
import dlib

import cv2
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull
from scipy.stats import linregress

detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")


def xywh2pt(rect):
    return [rect[0], rect[1], rect[0] + rect[2], rect[1] + rect[3]]


def pt2xywh(rect):
    return [rect[0], rect[1], rect[2] - rect[0], rect[3] - rect[1]]


def display_and_wait(image, message, wait=0, key_char=None):
    assert isinstance(wait, int)
    cv2.imshow(message + "... Press any key to continue" if key_char is None else
               message + "... Press key (key code: %d)" % key_char,
               image)
    key = cv2.waitKey(wait)
    cv2.destroyAllWindows() if key_char is None else (
        cv2.destroyAllWindows() if key == key_char else print("KeyCode: %d, Press" % key))
    return key


kp_dict_68 = {
    "nose": list(range(27, 36, 1)),
    "left_eye": list(range(42, 48, 1)),
    "right_eye": list(range(36, 42, 1)),
    "lips": list(range(48, 68)),
    "right_brow": list(range(17, 22, 1)),
    "left_brow": list(range(22, 27, 1)),
    "left_cheek": list(range(11, 17, 1)) + list(range(28, 36, 1)),
    "right_cheek": list(range(0, 6, 1)) + list(range(28, 36, 1)),
    "left_chin": [5, 6, 7, 8, 48, 57, 58, 59],
    "right_chin": [8, 9, 10, 11, 54, 55, 56, 57]
}


def reflect_point_wrt_line_2d(slope, intercept, x1, y1, scale=1.):
    if np.abs(slope) < 1e-8:
        slope = 1e-8
    u = (x1 + slope * y1 - slope * intercept) / (slope ** 2 + 1)
    v = slope * u + intercept
    x2 = u + (u - x1) * scale
    y2 = v + (v - y1) * scale
    # print((x1, y1), "y=%3.3fx+%3.3f" % (float(slope), float(intercept)), (u, v), (x2, y2))
    return x2, y2


def list_difference(list1, list2):
    return list(set(list1).difference(set(list2)))


def get_faces(np_image, scale=3):
    # convert to BGR
    if len(np_image.shape) > 2:
        if np_image.shape[2] > 3:
            im = np_image[:, :, 0:3][:, :, ::-1]
        else:
            im = np_image[:, :, ::-1]
    else:
        im = np_image
    rect_list = detector(im, scale)
    return rect_list


def get_facial_landmarks(np_image, face_bb):
    shape = predictor(np_image, face_bb)
    return shape


def get_overlay(mask, im):
    overlay = np.repeat(np.expand_dims(mask, axis=2), repeats=3, axis=2).astype(np.float) / 8 + im.astype(np.float)
    overlay = (255 * (overlay - np.min(overlay, axis=None)) /
               (np.max(overlay, axis=None) - np.min(overlay, axis=None))).astype(np.uint8)
    return overlay


def facial_region_mask_from_keypoints(np_image, landmarks, keypoint_idx):
    im = np.zeros(shape=(np_image.shape[0], np_image.shape[1]), dtype=np.uint8)
    pts = np.zeros(shape=(len(keypoint_idx), 2), dtype=np.int32)
    for i in range(len(keypoint_idx)):
        pts[i, 0] = landmarks.part(keypoint_idx[i]).x
        pts[i, 1] = landmarks.part(keypoint_idx[i]).y
    nose_hull = ConvexHull(pts)
    nose_poly_vertices = np.array([pts[nose_hull.vertices, :]])
    im = cv2.fillPoly(im, nose_poly_vertices, color=(255,))
    return im


def facial_region_mask(np_image, face_bb, region="nose", landmarks=None):
    assert region in list(kp_dict_68.keys())

    if landmarks is None:
        landmarks = get_facial_landmarks(np_image, face_bb)
    return facial_region_mask_from_keypoints(np_image, landmarks, kp_dict_68[region])


def im_difference(im1, im2, margin=1):
    margin = 1 if margin < 1 else margin
    return im1 * (255 - cv2.dilate(im2, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), iterations=margin))


def im_difference_list(im1, im_list, margin=1):
    res = im1.copy()
    for im in im_list:
        res = res * (255 - cv2.dilate(im, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), iterations=margin))
    return res


def predicted_left_forehead(np_image, face_bb, landmarks=None, beta=0.36):
    if landmarks is None:
        landmarks = get_facial_landmarks(np_image, face_bb)
    left_brow_keypoints = kp_dict_68["left_brow"]

    try:
        left_brow_keypoints.remove(22)
    except ValueError:
        print(ValueError)

    right_brow_keypoints = kp_dict_68["right_brow"]
    left_cheek_keypoints = list(range(9, 15, 1))
    im = np.zeros(shape=(np_image.shape[0], np_image.shape[1]), dtype=np.uint8)

    pts = np.zeros(shape=(len(left_brow_keypoints) + len(left_cheek_keypoints), 2), dtype=np.int32)
    pts_ = np.zeros(shape=(len(right_brow_keypoints) + len(left_brow_keypoints), 2), dtype=np.float)

    for i in range(len(left_brow_keypoints)):
        pts[i, 0] = landmarks.part(left_brow_keypoints[i]).x
        pts[i, 1] = landmarks.part(left_brow_keypoints[i]).y
        pts_[i, 0] = landmarks.part(left_brow_keypoints[i]).x
        pts_[i, 1] = landmarks.part(left_brow_keypoints[i]).y
    for j in range(len(right_brow_keypoints)):
        i = j + len(left_brow_keypoints)
        pts_[i, 0] = landmarks.part(right_brow_keypoints[j]).x
        pts_[i, 1] = landmarks.part(right_brow_keypoints[j]).y

    slope, intercept, _, _, err = linregress(pts_[:, 0], pts_[:, 1])
    print("y = %3.3fx + %3.3f" % (slope, intercept))

    for j in range(len(left_cheek_keypoints)):
        i = j + len(left_brow_keypoints)
        pts[i, :] = reflect_point_wrt_line_2d(slope, intercept,
                                              landmarks.part(left_cheek_keypoints[j]).x,
                                              landmarks.part(left_cheek_keypoints[j]).y,
                                              beta)
    nose_hull = ConvexHull(pts)
    nose_poly_vertices = np.array([pts[nose_hull.vertices, :]])
    im = cv2.fillPoly(im, nose_poly_vertices, color=(255,))
    return im


def predicted_right_forehead(np_image, face_bb, landmarks=None, beta=0.36):
    if landmarks is None:
        landmarks = get_facial_landmarks(np_image, face_bb)
    right_brow_keypoints = kp_dict_68["right_brow"]
    try:
        right_brow_keypoints.remove(21)
    except ValueError:
        print(ValueError)

    left_brow_keypoints = kp_dict_68["left_brow"]
    right_cheek_keypoints = list(range(2, 8, 1))
    im = np.zeros(shape=(np_image.shape[0], np_image.shape[1]), dtype=np.uint8)

    pts = np.zeros(shape=(len(right_brow_keypoints) + len(right_cheek_keypoints), 2), dtype=np.int32)
    pts_ = np.zeros(shape=(len(right_brow_keypoints) + len(left_brow_keypoints), 2), dtype=np.float)

    for i in range(len(right_brow_keypoints)):
        pts[i, 0] = landmarks.part(right_brow_keypoints[i]).x
        pts[i, 1] = landmarks.part(right_brow_keypoints[i]).y
        pts_[i, 0] = landmarks.part(right_brow_keypoints[i]).x
        pts_[i, 1] = landmarks.part(right_brow_keypoints[i]).y
    for j in range(len(left_brow_keypoints)):
        i = j + len(right_brow_keypoints)
        pts_[i, 0] = landmarks.part(left_brow_keypoints[j]).x
        pts_[i, 1] = landmarks.part(left_brow_keypoints[j]).y

    slope, intercept, _, _, err = linregress(pts_[:, 0], pts_[:, 1])

    for j in range(len(right_cheek_keypoints)):
        i = j + len(right_brow_keypoints)
        pts[i, :] = reflect_point_wrt_line_2d(slope, intercept,
                                              landmarks.part(right_cheek_keypoints[j]).x,
                                              landmarks.part(right_cheek_keypoints[j]).y,
                                              beta)
    nose_hull = ConvexHull(pts)
    nose_poly_vertices = np.array([pts[nose_hull.vertices, :]])
    im = cv2.fillPoly(im, nose_poly_vertices, color=(255,))
    return im


def predicted_full_forehead(np_image, face_bb, landmarks=None, beta=0.36):
    if landmarks is None:
        landmarks = get_facial_landmarks(np_image, face_bb)
    right_brow_keypoints = kp_dict_68["right_brow"]
    left_brow_keypoints = kp_dict_68["left_brow"]
    cheek_keypoints = list(range(3, 14, 1))
    im = np.zeros(shape=(np_image.shape[0], np_image.shape[1]), dtype=np.uint8)

    pts = np.zeros(shape=(len(right_brow_keypoints) + len(left_brow_keypoints) + len(cheek_keypoints), 2),
                   dtype=np.int32)

    for i in range(len(right_brow_keypoints)):
        pts[i, 0] = landmarks.part(right_brow_keypoints[i]).x
        pts[i, 1] = landmarks.part(right_brow_keypoints[i]).y
    for j in range(len(left_brow_keypoints)):
        i = j + len(right_brow_keypoints)
        pts[i, 0] = landmarks.part(left_brow_keypoints[j]).x
        pts[i, 1] = landmarks.part(left_brow_keypoints[j]).y

    slope, intercept, _, _, err = linregress(pts[:len(right_brow_keypoints) + len(left_brow_keypoints), 0],
                                             pts[:len(right_brow_keypoints) + len(left_brow_keypoints), 1])

    for j in range(len(cheek_keypoints)):
        i = j + len(right_brow_keypoints) + len(left_brow_keypoints)
        pts[i, :] = reflect_point_wrt_line_2d(slope, intercept,
                                              landmarks.part(cheek_keypoints[j]).x,
                                              landmarks.part(cheek_keypoints[j]).y,
                                              beta)
    nose_hull = ConvexHull(pts)
    nose_poly_vertices = np.array([pts[nose_hull.vertices, :]])
    im = cv2.fillPoly(im, nose_poly_vertices, color=(255,))
    return im


def facial_planar_parts_mask(frame, face_d, landmarks, extended=False):
    left_cheek = facial_region_mask(frame, face_d, "left_cheek")
    right_cheek = facial_region_mask(frame, face_d, "right_cheek")
    left_brow = facial_region_mask(frame, face_d, "left_brow")
    right_brow = facial_region_mask(frame, face_d, "right_brow")
    left_chin = facial_region_mask(frame, face_d, "left_chin")
    right_chin = facial_region_mask(frame, face_d, "right_chin")
    lips = facial_region_mask(frame, face_d, "lips")
    nose = facial_region_mask(frame, face_d, "nose")
    left_eye = facial_region_mask(frame, face_d, "left_eye")
    right_eye = facial_region_mask(frame, face_d, "right_eye")

    full_forehead = predicted_full_forehead(frame, face_d, landmarks)
    left_forehead = predicted_left_forehead(frame, face_d, landmarks)
    right_forehead = predicted_right_forehead(frame, face_d, landmarks)

    s9 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    s3 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    erode_amount = 2
    filter_amount = 5

    left_eye_filtered = im_difference_list(left_eye, [left_brow, left_cheek, nose], margin=1)
    left_eye_filtered = cv2.morphologyEx(left_eye_filtered, cv2.MORPH_DILATE, s3, iterations=10)

    right_eye_filtered = im_difference_list(right_eye, [left_brow, right_cheek, nose], margin=1)
    right_eye_filtered = cv2.morphologyEx(right_eye_filtered, cv2.MORPH_DILATE, s3, iterations=10)

    nose_filtered = im_difference_list(nose, [left_eye, right_eye], margin=1)
    nose_filtered = cv2.morphologyEx(nose_filtered, cv2.MORPH_DILATE, s3, iterations=3)

    left_cheek_filtered = im_difference_list(left_cheek, [right_cheek, left_chin, left_brow, nose, lips], 2)
    if not extended:
        left_cheek_filtered = cv2.morphologyEx(left_cheek_filtered, cv2.MORPH_OPEN, s9, iterations=filter_amount)
        left_cheek_filtered = cv2.morphologyEx(left_cheek_filtered, cv2.MORPH_ERODE, s3, iterations=erode_amount)

    right_cheek_filtered = im_difference_list(right_cheek, [left_cheek, right_chin, right_brow, nose, lips], 2)
    if not extended:
        right_cheek_filtered = cv2.morphologyEx(right_cheek_filtered, cv2.MORPH_OPEN, s9, iterations=filter_amount)
        right_cheek_filtered = cv2.morphologyEx(right_cheek_filtered, cv2.MORPH_ERODE, s3, iterations=erode_amount)

    left_chin_filtered = im_difference_list(left_chin, [lips, left_cheek, right_chin], margin=1)
    if not extended:
        left_chin_filtered = cv2.morphologyEx(left_chin_filtered, cv2.MORPH_OPEN, s9, iterations=filter_amount)
        left_chin_filtered = cv2.morphologyEx(left_chin_filtered, cv2.MORPH_ERODE, s3, iterations=erode_amount)

    right_chin_filtered = im_difference_list(right_chin, [lips, right_cheek, left_chin], margin=1)
    if not extended:
        right_chin_filtered = cv2.morphologyEx(right_chin_filtered, cv2.MORPH_OPEN, s9, iterations=filter_amount)
        right_chin_filtered = cv2.morphologyEx(right_chin_filtered, cv2.MORPH_ERODE, s3, iterations=erode_amount)

    central_forehead_filtered = im_difference_list(full_forehead, [left_brow, right_brow], margin=2)
    central_forehead_filtered = im_difference_list(central_forehead_filtered, [left_forehead, right_forehead], margin=1)
    central_forehead_filtered = cv2.morphologyEx(central_forehead_filtered, cv2.MORPH_OPEN, s9,
                                                 iterations=filter_amount)
    if not extended:
        central_forehead_filtered = cv2.morphologyEx(central_forehead_filtered, cv2.MORPH_ERODE, s3,
                                                     iterations=erode_amount)

    left_forehead_filtered = im_difference_list(left_forehead, [left_brow, right_brow], margin=0)
    left_forehead_filtered = im_difference_list(left_forehead_filtered, [central_forehead_filtered], margin=1)
    if not extended:
        left_forehead_filtered = cv2.morphologyEx(left_forehead_filtered, cv2.MORPH_OPEN, s9, iterations=filter_amount)
        left_forehead_filtered = cv2.morphologyEx(left_forehead_filtered, cv2.MORPH_ERODE, s3, iterations=erode_amount)

    right_forehead_filtered = im_difference_list(right_forehead, [left_brow, right_brow], margin=0)
    right_forehead_filtered = im_difference_list(right_forehead_filtered, [central_forehead_filtered], margin=1)
    if not extended:
        right_forehead_filtered = cv2.morphologyEx(right_forehead_filtered, cv2.MORPH_OPEN, s9,
                                                   iterations=filter_amount)
        right_forehead_filtered = cv2.morphologyEx(right_forehead_filtered, cv2.MORPH_ERODE, s3,
                                                   iterations=erode_amount)

    parts_to_track = [left_cheek_filtered, right_cheek_filtered,
                      left_chin_filtered, right_chin_filtered,
                      left_forehead_filtered, right_forehead_filtered,
                      central_forehead_filtered]
    if extended:
        parts_to_track.append(left_eye_filtered)
        parts_to_track.append(right_eye_filtered)
        parts_to_track.append(nose_filtered)
    return parts_to_track


def track_color_volume(video, parts_to_track, initial_grids, initial_frame, num_frames=1000, preprocess=None):
    reference_kp_to_track = []
    n_parts = len(parts_to_track)

    for i in range(n_parts):
        reference_kp_to_track.append(
            numpy.squeeze(cv2.goodFeaturesToTrack(cv2.cvtColor(initial_frame, cv2.COLOR_BGR2GRAY),
                                                  50, 0.01, 2, None, parts_to_track[i])))
    lk_params = dict(winSize=(10, 10),
                     maxLevel=2,
                     criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))

    tracker = [[part.tolist() for part in reference_kp_to_track], ]
    tracker_validity = [[[True for _ in range(part.shape[0])] for part in reference_kp_to_track], ]
    last_frame = initial_frame.copy()
    last_frame_gray = cv2.cvtColor(last_frame, cv2.COLOR_BGR2GRAY)
    color_volume = [[[] for __ in _] for _ in initial_grids]

    counter = -1
    while video.isOpened() & (counter < num_frames):
        counter += 1

        status, new_frame = video.read()
        if not status:
            break
        if preprocess is not None:
            new_frame = preprocess(new_frame)

        new_frame_gray = cv2.cvtColor(new_frame, cv2.COLOR_BGR2GRAY)
        new_kp_to_track = []
        new_validity = []

        for i in range(len(parts_to_track)):
            p0 = numpy.array(tracker[-1][i], dtype=numpy.float32).reshape(-1, 1, 2)
            p1, _, _ = cv2.calcOpticalFlowPyrLK(last_frame_gray, new_frame_gray, p0, None, **lk_params)
            p0r, _, _ = cv2.calcOpticalFlowPyrLK(new_frame_gray, last_frame_gray, p1, None, **lk_params)
            d = abs(p0 - p0r).reshape(-1, 2).max(-1)
            good = (d < 1).tolist()

            new_validity.append([(good[j] and tracker_validity[-1][i][j]) for j in range(len(good))])
            new_kp_to_track.append(numpy.squeeze(p1).tolist())

        tracker_validity.append(new_validity)
        tracker.append(new_kp_to_track)
        last_frame_gray = new_frame_gray.copy()

        canvas_parts = [numpy.zeros(initial_frame.shape[0:2]) for i in range(3)]

        for part_i in range(len(tracker[0])):
            ref_part = numpy.array(tracker[0][part_i])
            new_part = numpy.array(tracker[-1][part_i])
            homography, status = cv2.findHomography(ref_part, new_part)

            new_frame_registered = cv2.warpPerspective(new_frame, homography, new_frame.shape[::-1][1:])

            part_mask_tracked = cv2.warpPerspective(parts_to_track[part_i], homography,
                                                    parts_to_track[part_i].shape[::-1])  # (width, height) > ::-1
            for channel in range(3):
                canvas_parts[channel][part_mask_tracked > 0] = colors[part_i][channel]

            for grid_i in range(len(initial_grids[part_i])):
                init_rect = initial_grids[part_i][grid_i]
                temp = new_frame_registered[int(init_rect[1]): int(init_rect[3]),
                                            int(init_rect[0]): int(init_rect[2]), :]

                color_volume[part_i][grid_i].append(
                    [temp[:, :, channel].mean() for channel in range(3)])

        canvas_parts = numpy.dstack(canvas_parts).astype(numpy.uint8)

        cv2.imshow(color_volume_msg, canvas_parts)
        key = cv2.waitKey(1)
        if key == 27:
            break
        if counter % 25 == 0:
            print("%d frames processed..." % counter)

    cv2.destroyWindow(color_volume_msg)
    return color_volume
