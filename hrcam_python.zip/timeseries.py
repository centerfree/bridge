import numpy


def zero_mean(arr: numpy.ndarray, axis: int=0):
    assert axis < arr.ndim
    mu = arr.mean(axis=axis, keepdims=True)
    mu = numpy.repeat(mu, repeats=arr.shape[axis], axis=axis)
    return arr-mu


def unit_std(arr: numpy.ndarray, axis: int=0, eps=1e-6):
    assert axis < arr.ndim
    std = arr.std(axis=axis, keepdims=True)
    std = numpy.repeat(std, repeats=arr.shape[axis], axis=axis)
    return arr/(std + eps)


def norm1(arr: numpy.ndarray, axis: int = 0, eps=0.0000001):
    min_arr = numpy.repeat(numpy.min(arr, axis=axis, keepdims=True), repeats=arr.shape[axis], axis=axis)
    max_arr = numpy.repeat(numpy.max(arr, axis=axis, keepdims=True), repeats=arr.shape[axis], axis=axis)
    return (2 * arr - min_arr - max_arr) / (max_arr - min_arr + eps)


def norm_correlation_matrix(sig: numpy.ndarray, channel_axis: int=0, eps=0.0000001):
    assert sig.ndim == 2
    n_channels = sig.shape[channel_axis]
    sig_ = zero_mean(sig, axis=1-channel_axis)
    energy = numpy.sum(numpy.square(sig_), axis=1-channel_axis)
    energy_prod = energy.reshape(-1, 1).dot(energy.reshape(1, -1)) + eps
    return sig_.dot(sig_.transpose()) / numpy.sqrt(energy_prod)


if __name__ == '__main__':
    a = numpy.random.rand(10, 1000)
    mix = numpy.random.rand(10, 10)
    b = mix.dot(a)
    corr = norm_correlation_matrix(b, channel_axis=0)

    from matplotlib import pyplot as plotter
    plotter.matshow(mix)
    plotter.figure()
    plotter.matshow(corr)

