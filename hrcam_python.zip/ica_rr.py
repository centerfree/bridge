import numpy as np
from sklearn.decomposition import FastICA
from skvideo.io import FFmpegReader
import cv2
import matplotlib.pyplot as plt
from scipy.signal import convolve2d, butter, filtfilt, freqz, freqs, cheby1
from animation import animate_line_plot as animate


_and = np.logical_and


class ROI:
    def __init__(self, left, right, top, bottom):
        """

        :param left:
        :type left: int
        :param right:
        :type right: int
        :param top:
        :type top: int
        :param bottom:
        :type bottom: int
        """
        self.lc = left
        self.rc = right
        self.tc = top
        self.bc = bottom

    def area(self):
        return (self.rc - self.lc + 1) * (self.tc - self.bc + 1)

    def inside(self, x, y):
        return _and(_and(x >= self.lc, x <= self.rc), _and(y >= self.tc, y <= self.bc))

    def crop(self, image):
        if len(image.shape) == 3:
            return image[self.tc: self.bc + 1, self.lc: self.rc + 1, :]
        else:
            return image[self.tc: self.bc + 1, self.lc: self.rc + 1]


vid_path = "../videos/ashish_apnea_sim.mp4"
video = FFmpegReader(vid_path)
seq_len = video._probCountFrames()
pixels = None

roi = ROI(left=200, right=900, top=800, bottom=1800)

kernel = np.ones((1, 1)) / 1

counter = 0
for frame in video.nextFrame():
    cv2.imshow(vid_path, roi.crop(frame[:, :, ::-1]))

    cropped = roi.crop(frame[:, :, ::-1]).astype(np.float)
    cropped = convolve2d(cropped[:, :, 2], kernel, 'same', 'wrap')
    cropped = cropped[3::5, 3::5]
    # print(cropped.shape)

    if counter == 0:
        pixels = np.zeros((seq_len, cropped.size))

    pixels[counter, :] = cropped.reshape(-1,)

    counter += 1
    key = cv2.waitKey(1)
    print(counter)
    if counter > seq_len - 1:
        break

n_components = 2
ica = FastICA(n_components=n_components)
y = ica.fit_transform(pixels)
fig, axes = plt.subplots(n_components, 1)
if n_components > 1:
    for i in range(n_components):
        axes[i].plot(np.arange(y.shape[0]) / 30.0, y[:, i], 'b')
else:
    axes.plot(np.arange(y.shape[0]) / 30.0, y, 'b')
plt.show()


filter_weights = cheby1(1, 0.2, [0.01/15.0, 1.0/15.0], btype='band')
pixels_filtered = filtfilt(*filter_weights, pixels, axis=0)

n_components = 3
ica = FastICA(n_components=n_components)
y = ica.fit_transform(pixels_filtered)
# y = y[1:] - y[:-1]

fig, axes = plt.subplots(n_components, 1)
colors = ['r', 'g', 'b', 'c', 'm', 'k']
if n_components > 1:
    for i in range(n_components):
        axes[i].plot(np.arange(y.shape[0]) / 24.0, y[:, i], colors[i])
else:
    axes.plot(np.arange(y.shape[0]) / 24.0, y, 'r')
plt.show()


plt.plot(np.linspace(-15, 15, y.size), np.log(np.abs(np.fft.fftshift(np.fft.fft(filtfilt(*filter_weights, y, axis=0)))) + 1e-10))
