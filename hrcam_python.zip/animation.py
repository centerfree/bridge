import numpy
import cv2
import math


def animate_line_plot(y, height=100, width=None, gx=None, gy=None):
    """

    :param y:
    :type y: numpy.ndarray [len]
    :param height:
    :type height:
    :param width:
    :type width:
    :param gx:
    :type gx:
    :param gy:
    :type gy:
    :return:
    :rtype: numpy.ndarray [len, height, width, 3]
    """
    if width is None:
        width = y.size
    ymin = y.min()
    ymax = y.max()

    # init canvas
    canvas = numpy.zeros((height, y.size, 3), dtype=numpy.uint8)

    # draw grids
    if gx is not None:
        if gx % 10 == 0:
            canvas[:, ::gx, :] = 25
        canvas[:, ::gx, :] = 50
    if gy is not None:
        if gy % 10 == 0:
            canvas[:, ::gy, :] = 25
        canvas[::gy, :, :] = 50

    video = numpy.zeros((len(y), height, width, 3), dtype=numpy.uint8)
    for i in range(len(y)):
        loc = height * 0.1 + (height * 0.8) * (y[i] - ymin) / (ymax - ymin)
        loc_ceil = min(math.ceil(loc), height)
        loc_floor = max(math.floor(loc), 0)

        canvas[loc_ceil, i, 1] = int(255 * (loc_ceil - loc))
        canvas[loc_floor, i, 1] = int(255 * (loc - loc_floor))
        video[i, ...] = cv2.resize(canvas, dsize=(width, height))
    return video


def play_volume(volume):
    for i in range(volume.shape[0]):
        cv2.imshow("animation", volume[i, ...])
        key = cv2.waitKey(33)
    cv2.destroyAllWindows()


if __name__ == '__main__':
    time = numpy.arange(1000) * 0.02
    sine = numpy.sin(time)
    animation = animate_line_plot(time, sine)

    for t in range(animation.shape[0]):
        cv2.imshow("animation", animation[t, ...])
        key = cv2.waitKey(33)
    cv2.destroyAllWindows()
