from skvideo.io import vread, vwrite
from animation import animate_line_plot, play_volume
import numpy
import cv2

vid_path = "../videos/ashish_apnea_sim_trim_compressed.mp4"

video_arr = vread(vid_path)

volume = animate_line_plot(y[:, 1], 100, width=video_arr.shape[1], gx=24, gy=11)
volume = volume.transpose((0, 2, 1, 3))
combined = numpy.concatenate([video_arr, volume], axis=2)

play_volume(combined)

vwrite('ashish_apnea_sim_trim_respiration.mp4', combined,
       outputdict={'-r': '24'})

vid1_path = "../videos/ir_vijay.mp4"
vid2_path = "../videos/plot_vijay.mp4"
vid1 = vread(vid1_path)
vid2 = vread(vid2_path)

vid12 = numpy.zeros((vid2.shape[0], vid2.shape[1], 2*vid2.shape[2], vid2.shape[3]))
for i in range(vid2.shape[0]):
    frame1 = cv2.resize(vid1[i, :, :, :], (vid2.shape[2], vid2.shape[1]))
    frame1 = numpy.concatenate((frame1, vid2[i, :, :, :]), axis=1)
    vid12[i, :, :, :] = frame1


out_path = "../videos/evap_vijay.wmv"
vwrite(out_path, vid12)
