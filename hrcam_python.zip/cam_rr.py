import cv2
from hr_cam_fast import skip_frames_till_stable_face_detected
import numpy
from scipy.signal import convolve2d
import pickle
from sklearn.decomposition import FastICA


_and = numpy.logical_and


class ROI:
    def __init__(self, left, right, top, bottom):
        """

        :param left:
        :type left: int
        :param right:
        :type right: int
        :param top:
        :type top: int
        :param bottom:
        :type bottom: int
        """
        self.lc = left
        self.rc = right
        self.tc = top
        self.bc = bottom

    def area(self):
        return (self.rc - self.lc + 1) * (self.tc - self.bc + 1)

    def inside(self, x, y):
        return _and(_and(x >= self.lc, x <= self.rc), _and(y >= self.tc, y <= self.bc))

    def crop(self, image):
        if len(image.shape) == 3:
            return image[self.tc: self.bc + 1, self.lc: self.rc + 1, :]
        else:
            return image[self.tc: self.bc + 1, self.lc: self.rc + 1]


def resp_rate(video_path: str, summary_path=None, frame_limit=1000, roi=None):

    def preprocess(numpy_image3):
        numpy_image3 = cv2.rotate(numpy_image3, cv2.ROTATE_90_CLOCKWISE)
        return numpy_image3

    if summary_path is None:
        summary_path = video_path[:-4] + '_summary_rr.bin' if isinstance(video_path, str) else '_summary_rr.bin'
    summary = dict()
    summary_writer = open(summary_path, 'wb')

    try:
        video = cv2.VideoCapture(video_path)
        fps = round(video.get(cv2.CAP_PROP_FPS))
        print("Video FPS is %d" % int(fps))
        summary['fps'] = fps

        face, frame = skip_frames_till_stable_face_detected(video, 0.05, preprocess=preprocess)

        if roi is None:
            roi = ROI(left=0, right=frame.shape[1], top=0, bottom=frame.shape[0])

        kernel = numpy.ones((1, 1)) / 1

        counter = 0
        pixels = None
        while True:
            status, frame = video.read()
            frame = preprocess(frame)
            if not status:
                break

            cv2.imshow(video_path, roi.crop(frame[:, :, ::-1]))

            cropped = roi.crop(frame).astype(numpy.float)
            cropped = convolve2d(cropped[:, :, 2], kernel, 'same', 'wrap')
            cropped = cropped[3::5, 3::5]

            if pixels is None:
                pixels = numpy.zeros((frame_limit, cropped.size))

            pixels[counter, :] = cropped.reshape(-1, )

            counter += 1
            cv2.waitKey(1)
            if counter > frame_limit - 1:
                cv2.destroyWindow(video_path)
                break

        n_components = 2
        ica = FastICA(n_components=n_components)
        resp_signal = ica.fit_transform(pixels)
        summary['resp_signal'] = resp_signal

    finally:
        try:
            pickle.dump(summary, summary_writer)
        finally:
            summary_writer.close()


if __name__ == '__main__':
    import pickle
    from matplotlib import pyplot as plotter

    vid_path = '../videos/ashish_apnea_sim.mp4'
    try:
        with open(vid_path[:-4] + '_summary_rr.bin', 'rb') as f:
            summary = pickle.load(f)
    except FileNotFoundError:
        resp_rate(vid_path)
        try:
            with open(vid_path[:-4] + '_summary_rr.bin', 'rb') as f:
                summary = pickle.load(f)
        except FileNotFoundError:
            print("FATAL ERROR,EXITING...")
            exit(0)
        exit(0)
    resp_signal = summary['resp_signal']
    plotter.plot(resp_signal)
    plotter.show()
