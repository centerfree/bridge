import cv2
import numpy
from itertools import compress
from time import process_time as time


class Timer:
    stamp = 0

    def __init__(self):
        self.restart()

    def restart(self):
        self.stamp = self.current_time()

    def start(self):
        self.restart()

    @staticmethod
    def current_time():
        return time()

    def elapsed_time(self):
        return self.current_time() - self.stamp

    def display(self, prefix=""):
        print(prefix + (" took %4.2f seconds..." % (self.elapsed_time())))


def cv_color(val):
    return tuple([int(c) for c in val])


def process_frame(numpy_image3):
    numpy_image3 = cv2.rotate(numpy_image3, cv2.ROTATE_90_CLOCKWISE)
    numpy_image3 = numpy_image3[int(numpy_image3.shape[0] / 4): int(3 * numpy_image3.shape[0] / 4), :, :]
    return numpy_image3


def draw_faces(numpy_image3, faces_list):
    for item in faces_list:
        cv2.rectangle(numpy_image3, (item[0], item[1]), (item[0] + item[2], item[1] + item[3]), (0, 255, 237), 2)
    return numpy_image3


def filter_key_points_and_descriptors(key_points, descriptors, rect):
    good = []
    for key_point in key_points:
        if key_point.pt[0] < rect[0] or key_point.pt[0] > rect[0] + rect[2] or key_point.pt[1] < rect[1] or \
                key_point.pt[1] > rect[1] + rect[3]:
            good.append(False)
        else:
            good.append(True)
    key_points = list(compress(key_points, good))
    descriptors = descriptors[good, :]
    return key_points, descriptors


def draw_key_points(numpy_image3, key_points):
    for key_point in key_points:
        cv2.drawMarker(numpy_image3, tuple(int(i) for i in key_point.pt), (0, 127, 255), thickness=2)
    return numpy_image3


def filter_matches_and_compute_matched_coordinates(reference_key_points, new_key_points, nn_matches,
                                                   ratio_threshold=0.7):
    good_matches = []
    matched_ref = []
    matched_new = []
    xy_ref = []
    xy_new = []
    for m, n in nn_matches:
        if m.distance <= ratio_threshold * n.distance:
            good_matches.append(cv2.DMatch(len(matched_new), len(matched_ref), 0))
            matched_ref.append(m.trainIdx)
            matched_new.append(m.queryIdx)
            xy_ref.append(reference_key_points[m.trainIdx].pt)
            xy_new.append(new_key_points[m.queryIdx].pt)
    xy_ref = numpy.array(xy_ref)
    xy_new = numpy.array(xy_new)
    return good_matches, xy_ref, xy_new, matched_ref, matched_new


def match_key_point_to_reference(kp_ref, kp_new, matched_ref, matched_new, good_matches):
    kp_updated = [None for i in range(len(kp_ref))]
    for match in good_matches:
        kp_updated[matched_ref[match.queryIdx]] = kp_new[matched_new[match.trainIdx]]
    return kp_updated


def draw_tracks(canvas, new_positions, colors):
    for i, key_point in enumerate(new_positions):
        if key_point is not None:
            canvas[int(key_point.pt[1]), int(key_point.pt[0]), :] = colors[i, :]
    return canvas


def overlay_tracks_and_frame(canvas, frame):
    overlay_at = numpy.mean(canvas, axis=2) > 0
    frame[overlay_at] = canvas[overlay_at]
    return frame


def divide_rect_to_grid(splits_x, splits_y, rect):
    width = int(rect[2] / float(splits_x))
    height = int(rect[3] / float(splits_y))
    top_left_corners_x = list(range(rect[0], rect[0] + rect[2], width))
    top_left_corners_y = list(range(rect[1], rect[1] + rect[3], height))
    x_grid, y_grid = numpy.meshgrid(top_left_corners_x, top_left_corners_y)
    return x_grid, y_grid, x_grid + width, y_grid + height


def divide_part_to_grid(part_mask, width, height, roi=None, threshold=0.95):
    if roi is None:
        roi = [0, 0] + list(part_mask.shape[::-1])   # (width, height) > ::-1
    top_left_corners_x = list(range(roi[0], roi[2], width))
    top_left_corners_y = list(range(roi[1], roi[3], height))
    x_grid, y_grid = numpy.meshgrid(top_left_corners_x, top_left_corners_y)
    grids = []
    for i in range(x_grid.shape[0]):
        for j in range(x_grid.shape[1]):
            rect = (x_grid[i, j], y_grid[i, j], x_grid[i, j] + width, y_grid[i, j] + height)
            if rect_in_mask(rect, part_mask, threshold):
                grids.append(rect)
    return grids


def rect_in_mask(rect, mask, threshold=0.95):
    mask_ = (mask > 0).astype(numpy.float)
    rect_ = [int(item) for item in rect]
    roi = mask_[rect_[1]: rect_[3], rect_[0]: rect_[2]]
    if roi.mean() > threshold:
        return True
    else:
        return False


def flow_to_bgr(flow):
    mag, ang = cv2.cartToPolar(flow[..., 0], flow[..., 1])
    hsv = numpy.zeros((flow.shape[0], flow.shape[1], 3), dtype=numpy.uint8)
    hsv[..., 1] = 255
    hsv[..., 0] = ang * 180 / numpy.pi / 2
    hsv[..., 2] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    return bgr


def tracks_to_sparse_flow(track_ref, track_new):
    flow = []
    for i in range(len(track_ref)):
        if track_new[i] is not None:
            x = track_ref[i].pt[0]
            y = track_ref[i].pt[1]
            dx = track_new[i].pt[0] - track_ref[i].pt[0]
            dy = track_new[i].pt[1] - track_ref[i].pt[1]
        else:
            x = -1
            y = -1
            dx = -1
            dy = -1
        flow.append([x, y, dx, dy])
    return numpy.array(flow)


def displace_sparse_flow(x, y, flow):
    good_idx = flow[:, 0] >= 0
    flow_ = flow[good_idx, :]
    dist = numpy.square(x - flow_[:, 0]) + numpy.square(y - flow_[:, 1]) + 1e-2
    dist = numpy.power(1. / dist, 0.1)
    fx = numpy.sum((dist * flow_[:, 2])) / numpy.sum(dist)
    fy = numpy.sum((dist * flow_[:, 3])) / numpy.sum(dist)
    return fx, fy


def draw_grids_list(frame, grids, inside_grid):
    canvas = numpy.zeros(frame.shape)

    for i in range(len(grids)):
        for j in range(len(grids[0])):
            if inside_grid[i, j]:
                cv2.rectangle(canvas,
                              (grids[i][j][0], grids[i][j][1]),
                              (grids[i][j][0] + grids[i][j][2], grids[i][j][1] + grids[i][j][3]),
                              (0, 255, 0), 1, cv2.LINE_8)
                cv2.rectangle(canvas,
                              (grids[i][j][0], grids[i][j][1]),
                              (grids[i][j][0] + grids[i][j][2], grids[i][j][1] + grids[i][j][3]),
                              (0, 127, 0), cv2.FILLED, cv2.LINE_AA)
            else:
                cv2.rectangle(canvas,
                              (grids[i][j][0], grids[i][j][1]),
                              (grids[i][j][0] + grids[i][j][2], grids[i][j][1] + grids[i][j][3]),
                              (0, 0, 255), 1, cv2.LINE_8)
                cv2.rectangle(canvas,
                              (grids[i][j][0], grids[i][j][1]),
                              (grids[i][j][0] + grids[i][j][2], grids[i][j][1] + grids[i][j][3]),
                              (0, 0, 127), cv2.FILLED, cv2.LINE_AA)
    return canvas


def draw_grids(frame, left_grid, top_grid, right_grid, bottom_grid, inside_grid):
    canvas = numpy.zeros(frame.shape)
    left_grid = left_grid.astype(numpy.int)
    right_grid = right_grid.astype(numpy.int)
    top_grid = top_grid.astype(numpy.int)
    bottom_grid = bottom_grid.astype(numpy.int)

    for i in range(left_grid.shape[0]):
        for j in range(left_grid.shape[1]):
            if inside_grid[i, j]:
                cv2.rectangle(canvas,
                              (left_grid[i, j], top_grid[i, j]),
                              (right_grid[i, j], bottom_grid[i, j]),
                              (0, 127, 0), cv2.FILLED, cv2.LINE_AA)
                cv2.rectangle(canvas,
                              (left_grid[i, j], top_grid[i, j]),
                              (right_grid[i, j], bottom_grid[i, j]),
                              (0, 255, 0), 1, cv2.LINE_8)
            else:
                cv2.rectangle(canvas,
                              (left_grid[i, j], top_grid[i, j]),
                              (right_grid[i, j], bottom_grid[i, j]),
                              (0, 0, 127), cv2.FILLED, cv2.LINE_AA)
                cv2.rectangle(canvas,
                              (left_grid[i, j], top_grid[i, j]),
                              (right_grid[i, j], bottom_grid[i, j]),
                              (0, 0, 255), 1, cv2.LINE_8)
    return canvas


def overlay(base, skin, alpha=0.8):
    dtype = base.dtype
    return (base.astype(numpy.float) * alpha + (1 - alpha) * skin.astype(numpy.float)).astype(dtype)


def map_fun2d(fun, arg_array_list, arg_non_indexed, n_return=1):
    ret = [numpy.zeros_like(arg_array_list[0]) for i in range(n_return)]
    for i in range(arg_array_list[0].shape[0]):
        for j in range(arg_array_list[0].shape[1]):
            temp = fun(*[item[i, j] for item in arg_array_list], *arg_non_indexed)
            for k in range(n_return):
                ret[k][i, j] = temp[k] if n_return > 1 else temp
    return ret if n_return > 1 else ret[0]


def deform(gl, gt, gr, gb, gl_ref, gt_ref, gr_ref, gb_ref, frame):
    roi = frame[gl: gr, gt: gb, :]
    roi = cv2.resize(roi, [gr_ref - gl_ref + 1, gb_ref - gt_ref + 1, 3], interpolation=cv2.INTER_LINEAR)
    return roi


def test_map_fun2d():
    a = numpy.random.randn(5, 5)
    b = numpy.random.randn(5, 5)
    fun = lambda x, y: x ** 2 + y ** 2
    c = map_fun2d(fun, [a, b], [])
    c_ = a ** 2 + b ** 2
    print(c)
    print(c_)


def compensate_flow(grid_left, grid_top, grid_right, grid_bottom, sparse_flow):
    tl_dx, tl_dy = map_fun2d(displace_sparse_flow, [grid_left, grid_top], [sparse_flow], 2)
    br_dx, br_dy = map_fun2d(displace_sparse_flow, [grid_right, grid_top], [sparse_flow], 2)
    return grid_left + tl_dx, grid_top + tl_dy, grid_right + br_dx, grid_bottom + br_dy


def compensate_flow_const(grid_left, grid_top, grid_right, grid_bottom, sparse_flow):
    dx = numpy.mean(sparse_flow, axis=0)[2]
    dy = numpy.mean(sparse_flow, axis=0)[3]

    print()
    return grid_left + dx, grid_top + dy, grid_right + dx, grid_bottom + dy


def compensate_flow_homo(grid_left, grid_top, grid_right, grid_bottom, sparse_flow):
    good_idx = sparse_flow[:, 0] >= 0
    homo, status = cv2.findHomography(sparse_flow[good_idx, 0:2] + sparse_flow[good_idx, 2:4],
                                      sparse_flow[good_idx, 0:2], cv2.SVD_FULL_UV)
    print(status, homo)
    tl_old = numpy.concatenate([grid_left.reshape(-1, 1),
                                grid_top.reshape(-1, 1),
                                numpy.ones_like(grid_left).reshape(-1, 1)], axis=1)
    br_old = numpy.concatenate([grid_right.reshape(-1, 1),
                                grid_bottom.reshape(-1, 1),
                                numpy.ones_like(grid_right).reshape(-1, 1)], axis=1)
    tl_new = tl_old.dot(homo)
    br_new = br_old.dot(homo)
    return tl_new[:, 0].reshape(grid_left.shape), \
           tl_new[:, 1].reshape(grid_left.shape), \
           br_new[:, 0].reshape(grid_left.shape), \
           br_new[:, 1].reshape(grid_left.shape)


if __name__ == '__main__':
    test_map_fun2d()
